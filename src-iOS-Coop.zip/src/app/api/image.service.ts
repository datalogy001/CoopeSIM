// src/app/auth.service.ts
import { Injectable } from '@angular/core';
import { SignInWithApple, AppleSignInResponse   } from "@ionic-native/sign-in-with-apple/ngx";

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor() { }

  
  
}