export enum Constants {
    IOS_APP_VERSION = '1.0.1',
    ANDROID_APP_VERSION = '1.0.1'
}
