import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mobiscroll-example',
  templateUrl: './mobiscroll-example.component.html',
  styleUrls: ['./mobiscroll-example.component.scss'],
})
export class MobiscrollExampleComponent  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
