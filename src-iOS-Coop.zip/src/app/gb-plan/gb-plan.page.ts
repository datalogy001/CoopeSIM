import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gb-plan',
  templateUrl: './gb-plan.page.html',
  styleUrls: ['./gb-plan.page.scss'],
})
export class GbPlanPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
