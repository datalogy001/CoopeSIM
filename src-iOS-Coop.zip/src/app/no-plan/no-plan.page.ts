import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-plan',
  templateUrl: './no-plan.page.html',
  styleUrls: ['./no-plan.page.scss'],
})
export class NoPlanPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
