import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-failed',
  templateUrl: './payment-failed.page.html',
  styleUrls: ['./payment-failed.page.scss'],
})
export class PaymentFailedPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
